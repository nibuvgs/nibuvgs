//
//  ViewController.swift
//  alertaction_register
//
//  Created by Iroid on 27/10/21.
//  Copyright © 2021 Iroid. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var emailText: UITextField!
    @IBOutlet weak var mobileText: UITextField!
    @IBOutlet weak var pswdText: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


    @IBAction func reg_act(_ sender: Any) {
        let alert = UIAlertController(title: "Alert", message: "Do you want to countinue?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: {(UIAlertAction)-> Void in
            let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "next") as? firstViewController
            self.navigationController?.pushViewController(vc!, animated: true)
            
        }))
        alert.addAction(UIAlertAction(title: "No", style: .default, handler: nil))
        
        self.present(alert, animated: true)
    }
}

